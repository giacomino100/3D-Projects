"""3D surface definition: depth field Z(x, y), stations S0..Sn, lofted slabs,
and the trim body (visible shell + rear returns).

The visible face is the surface  z = zf(x, y):
    zf = z_bow(x) + z_wrap(x) + (y + H/2) * tan(pitch(x))  - zf(0, 0)
 - z_bow  : gentle convex bow over the full length          (ASSUMED)
 - z_wrap : rearward wrap of the outer end around the corner (PHOTO_DERIVED, low)
 - pitch  : section rotation about X (top edge rearward), increasing over the
            wrap zone = local twist                         (ASSUMED)
The front-view silhouette is imposed by intersecting curved slabs with prisms
of the planform extruded along Z, so the projected outline is exact by
construction while the surface keeps compound curvature.
"""
import math
import numpy as np
import cadquery as cq

import parameters as P
from geometry import planform as PF

Z_LO, Z_HI = -80.0, 160.0   # prism extent along Z (covers full group depth)


def _u(x):
    return np.clip(np.asarray(x, float) / P.L, -0.1, 1.1)


def _wrap_frac(x):
    u = _u(x)
    return np.clip((u - P.X_WRAP_START) / (1.0 - P.X_WRAP_START), 0.0, None)


def pitch_rad(x):
    if getattr(P, "Z_STATIONS", None) is not None:
        return np.radians(_PITCH(np.asarray(x, float)))
    return math.radians(P.PITCH_DEG) + math.radians(P.TWIST_OUTER_DEG) * np.clip(_wrap_frac(x), 0, 1)


CROWN = getattr(P, "CROWN", 0.0)   # V2: transverse convexity of the visible face (mm at mid-height)


Z_STATIONS = getattr(P, "Z_STATIONS", None)   # V3-B: [(s, z_mid, pitch_deg), ...] station table


def _station_interp():
    from scipy.interpolate import PchipInterpolator
    st = np.asarray(Z_STATIONS, float)
    return PchipInterpolator(st[:, 0], st[:, 1], extrapolate=True), PchipInterpolator(st[:, 0], st[:, 2], extrapolate=True)


if Z_STATIONS is not None:
    _ZC, _PITCH = _station_interp()


RAIL_CROWN = getattr(P, "RAIL_CROWN", 0.0)     # V5: convex (rounded) section of each rail, sagitta in mm
_RAIL = None


def _rail_tables():
    """Per-s tables of the band edges (outer top/bottom, opening top/bottom) from the planform."""
    global _RAIL
    if _RAIL is None:
        o = PF.spline_points("outer", 6000); i = PF.spline_points("opening", 6000)
        ss = np.arange(np.floor(o[:, 0].min()), np.ceil(o[:, 0].max()) + 0.5, 0.5)
        yo, yi = o[:, 1].mean(), i[:, 1].mean()
        def tab(pts, up, yc):
            out = np.full(len(ss), np.nan)
            sel = pts[(pts[:, 1] > yc) if up else (pts[:, 1] <= yc)]
            idx = np.clip(np.round((sel[:, 0] - ss[0]) / 0.5).astype(int), 0, len(ss) - 1)
            for k in range(len(ss)):
                v = sel[idx == k, 1]
                if len(v):
                    out[k] = v.max() if up else v.min()
            ok = np.isfinite(out)
            return np.interp(ss, ss[ok], out[ok]) if ok.any() else out
        s_a, s_b = i[:, 0].min(), i[:, 0].max()
        _RAIL = dict(s=ss, ot=tab(o, True, yo), ob=tab(o, False, yo), it=tab(i, True, yi), ib=tab(i, False, yi),
                     s_a=s_a, s_b=s_b)
    return _RAIL


def rail_crown(x, y):
    """-RAIL_CROWN * 4t(1-t) across each rail (t = 0 at the outer edge, 1 at the opening edge),
    faded in/out over RAIL_CROWN_FADE mm at both ends of the opening. 0 elsewhere (plate)."""
    if RAIL_CROWN == 0.0:
        return 0.0
    T = _rail_tables(); x = np.asarray(x, float); y = np.asarray(y, float)
    ot, ob, it, ib = (np.interp(x, T["s"], T[k]) for k in ("ot", "ob", "it", "ib"))
    fade = getattr(P, "RAIL_CROWN_FADE", 15.0)
    w = np.clip((x - T["s_a"]) / fade, 0, 1) * np.clip((T["s_b"] - x) / fade, 0, 1)
    tu = np.clip((ot - y) / np.maximum(ot - it, 1e-6), 0, 1); up = (y <= ot) & (y >= it)
    tl = np.clip((y - ob) / np.maximum(ib - ob, 1e-6), 0, 1); lo = (y >= ob) & (y <= ib)
    z = np.where(up, 4 * tu * (1 - tu), 0.0) + np.where(lo, 4 * tl * (1 - tl), 0.0)
    return -RAIL_CROWN * w * z


def _zf_raw(x, y):
    if Z_STATIONS is not None:   # V3-B: shape-preserving interpolation between measured stations
        x = np.asarray(x, float); y = np.asarray(y, float)
        v = np.clip(-y / P.H, 0.0, 1.0)
        return (_ZC(x) + (y + P.H / 2.0) * np.tan(np.radians(_PITCH(x))) - CROWN * 4.0 * v * (1.0 - v)
                + rail_crown(x, y))
    u = _u(x)
    y = np.asarray(y, float)
    z_bow = -P.Z_SAG_MAIN * 4.0 * u * (1.0 - u)
    z_wrap = P.Z_WRAP_OUTER * _wrap_frac(x) ** P.WRAP_EXP
    v = np.clip(-y / P.H, 0.0, 1.0)
    z_crown = -CROWN * 4.0 * v * (1.0 - v)
    return z_bow + z_wrap + (y + P.H / 2.0) * np.tan(pitch_rad(x)) + z_crown


_Z0 = float(_zf_raw(0.0, 0.0))


def zf(x, y):
    """Front (visible) face depth at (x, y)."""
    return _zf_raw(x, y) - _Z0


def dzdx(x, y=None, h=0.5):
    y = -P.H / 2 if y is None else y
    return (zf(x + h, y) - zf(x - h, y)) / (2 * h)


def stations(n=None):
    """Longitudinal stations S0..S(n-1) with geometry descriptors (for docs)."""
    n = n or P.N_STATIONS
    xs = np.linspace(0.0, P.L, n)
    out = []
    for i, x in enumerate(xs):
        ytop = 0.0
        ybot = -P.H
        # visible band widths at this X
        if x < P.OPEN_X0:
            band = "solid plate"
        elif x > PF.outer_x_at(-P.W_TOP) - P.W_OUTER:
            band = "outer end loop"
        else:
            band = f"top {P.W_TOP} / bottom {P.W_BOT}"
        zc = float(zf(x, -P.H / 2))
        s = float(dzdx(x))
        tangent = np.array([1.0, 0.0, s]); tangent /= np.linalg.norm(tangent)
        pr = pitch_rad(x)
        # surface normal pointing forward (out of the visible face, -Z)
        dzdy = math.tan(pr)
        nrm = np.array([s, dzdy, -1.0]); nrm /= np.linalg.norm(nrm)
        out.append(dict(name=f"S{i}", x=float(x), y_top=ytop, y_bot=ybot, y_mid=-P.H / 2,
                        z_mid=zc, z_top=float(zf(x, 0.0)), z_bot=float(zf(x, -P.H)),
                        tangent=tangent.round(4).tolist(), normal=nrm.round(4).tolist(),
                        pitch_deg=math.degrees(pr), band=band,
                        ret_outer=P.D_RET_OUTER, ret_top=P.D_RET_TOP))
    return out


def slab(z_off0, z_off1, n=None, x_margin=20.0, y_margin=20.0):
    """Curved slab between zf+z_off0 and zf+z_off1, lofted through X-sections."""
    n = n or max(P.N_STATIONS, 15)
    xs = np.linspace(-x_margin, P.L + x_margin, n)
    y0, y1 = -P.H - y_margin, y_margin
    wires = []
    for x in xs:
        if CROWN == 0.0:   # V1: straight sections (face linear in y)
            a = cq.Vector(x, y0, float(zf(x, y0)) + z_off0)
            b = cq.Vector(x, y1, float(zf(x, y1)) + z_off0)
            c = cq.Vector(x, y1, float(zf(x, y1)) + z_off1)
            d = cq.Vector(x, y0, float(zf(x, y0)) + z_off1)
            wires.append(cq.Wire.makePolygon([a, b, c, d], close=True))
        else:              # V2: curved sections (crown), spline front/back curves
            ys = np.linspace(y0, y1, getattr(P, "SECTION_PTS", 11))
            fr = [cq.Vector(x, float(y), float(zf(x, y)) + z_off0) for y in ys]
            bk = [cq.Vector(x, float(y), float(zf(x, y)) + z_off1) for y in ys[::-1]]
            e = [cq.Edge.makeSpline(fr), cq.Edge.makeLine(fr[-1], bk[0]),
                 cq.Edge.makeSpline(bk), cq.Edge.makeLine(bk[-1], fr[0])]
            wires.append(cq.Wire.assembleEdges(e))
    return cq.Solid.makeLoft(wires, ruled=False)


def prism(wire):
    """Extrude a planar XY wire along Z through the full depth range."""
    w = wire.moved(cq.Location(cq.Vector(0, 0, Z_LO)))
    f = cq.Face.makeFromWires(w)
    return cq.Solid.extrudeLinear(f, cq.Vector(0, 0, Z_HI - Z_LO))


def build_body():
    """Visible shell + rear returns, fused. Returns (shape, report dict)."""
    rep = {}
    outer = prism(PF.outer_wire())
    outer_in = prism(PF.outer_wire(offset=-P.T_WALL))
    opening = prism(PF.opening_wire())
    opening_out = prism(PF.opening_wire(offset=+P.T_WALL))

    shell = slab(0.0, P.T_SHELL).intersect(outer).cut(opening)

    ring_outer = outer.cut(outer_in)
    ret_outer = slab(P.T_SHELL - 0.2, P.T_SHELL + P.D_RET_OUTER).intersect(ring_outer)

    ring_open = opening_out.cut(opening)
    ret_open = slab(P.T_SHELL - 0.2, P.T_SHELL + P.D_RET_OPEN).intersect(ring_open)

    # deeper return along the top edge only (top bar), between tip and outer corner
    top_box = cq.Solid.makeBox(P.L - 2 * P.R_TIP - P.R_OUTER_TOP - 6, 6.0, Z_HI - Z_LO,
                               cq.Vector(P.R_TIP + 4, -6.0 + 0.01, Z_LO))
    ret_top = slab(P.T_SHELL - 0.2, P.T_SHELL + P.D_RET_TOP).intersect(ring_outer).intersect(top_box)

    body = shell.fuse(ret_outer).fuse(ret_open).fuse(ret_top).clean()

    if P.EDGE_FILLET > 0:
        try:
            # front perimeter edges = edges of the shell lying on the visible face
            front_edges = [e for e in body.Edges()
                           if abs(e.Center().z - float(zf(e.Center().x, e.Center().y))) < 0.3]
            body = body.fillet(P.EDGE_FILLET, front_edges)
            rep["edge_fillet"] = f"applied r={P.EDGE_FILLET} on {len(front_edges)} front edges"
        except Exception as ex:  # documented fallback, see docs/assumptions.md
            rep["edge_fillet"] = f"NOT applied (OCC fillet failed: {type(ex).__name__}); sharp edges in V1"
    rep["body_valid"] = body.isValid()
    rep["body_volume_mm3"] = body.Volume()
    return body, rep


# ---------------------------------------------------------------------------
# V2 body: lip return on the outer perimeter, deep wall on the TOP edge of the
# opening ending with a step (pru_1, fre_3, fre_4, pru_4), shallow return on the
# rest of the opening, separate edge radii.
# ---------------------------------------------------------------------------
def _classify_front_edges(body):
    """Return (outer_front_edges, opening_front_edges) lying on the visible face."""
    o = PF.outline_polyline("outer", 1.0); i = PF.outline_polyline("opening", 1.0)
    from scipy.spatial import cKDTree
    ko, ki = cKDTree(o), cKDTree(i)
    outer, opening = [], []
    for e in body.Edges():
        pts = [e.positionAt(t) for t in (0.2, 0.5, 0.8)]
        if max(abs(q.z - float(zf(q.x, q.y))) for q in pts) > 0.35:
            continue
        c = pts[1]
        do, di = ko.query([c.x, c.y])[0], ki.query([c.x, c.y])[0]
        if min(do, di) > 1.5:
            continue
        (outer if do < di else opening).append(e)
    return outer, opening


def build_body_v2():
    """Builds the body; verifies every boolean by volume (OCC can fail SILENTLY on
    spline prisms depending on the spline discretisation) and retries with other
    SPLINE_SEG_PTS values. Raises if no discretisation gives consistent volumes."""
    base_pts = getattr(P, "SPLINE_SEG_PTS", 28)
    tried = []
    for npts in [base_pts, 60, 40, 48, 36, 56, 64, 44, 52, 32]:
        if npts in tried:
            continue
        tried.append(npts)
        P.SPLINE_SEG_PTS = npts
        try:
            body, rep = _build_body_v2_once()
        except _BoolCheck as ex:
            print(f"[build_body_v2] SPLINE_SEG_PTS={npts}: boolean check failed ({ex}) -> retry", flush=True)
            continue
        rep["spline_seg_pts"] = npts
        rep["spline_seg_pts_tried"] = tried
        return body, rep
    raise RuntimeError(f"build_body_v2: boolean volume checks failed for SPLINE_SEG_PTS in {tried}")


class _BoolCheck(Exception):
    pass


def _check(label, got, expected, tol=0.12):
    if expected > 0 and abs(got - expected) > tol * expected:
        raise _BoolCheck(f"{label}: {got:.0f} mm3 vs expected ~{expected:.0f} mm3")


def _ring_prism(w_outer, w_inner):
    """Planar face with a hole, extruded through the full depth (more robust than
    prism(outer).cut(prism(inner)) for dense spline outlines)."""
    a = w_outer.moved(cq.Location(cq.Vector(0, 0, Z_LO)))
    b = w_inner.moved(cq.Location(cq.Vector(0, 0, Z_LO)))
    f = cq.Face.makeFromWires(a, [b])
    return cq.Solid.extrudeLinear(f, cq.Vector(0, 0, Z_HI - Z_LO))


def _valid(label, shape):
    if not shape.isValid():
        raise _BoolCheck(f"{label}: invalid OCC shape")
    return shape


def _build_body_v2_once():
    rep = {}
    outer = prism(PF.outer_wire())
    opening = prism(PF.opening_wire())
    A_out = cq.Face.makeFromWires(PF.outer_wire()).Area()
    A_open = cq.Face.makeFromWires(PF.opening_wire()).Area()
    A_out_in = cq.Face.makeFromWires(PF.outer_wire(offset=-P.T_RETURN)).Area()
    A_open_out = cq.Face.makeFromWires(PF.opening_wire(offset=+P.T_WALL_OPEN)).Area()
    skin_ring = _valid("skin ring", _ring_prism(PF.outer_wire(), PF.opening_wire()))
    skin = _valid("skin", slab(0.0, P.T_SKIN, n=P.N_LOFT).intersect(skin_ring))
    _check("skin", skin.Volume(), (A_out - A_open) * P.T_SKIN, tol=0.05)
    ring_outer = _valid("outer ring", _ring_prism(PF.outer_wire(), PF.outer_wire(offset=-P.T_RETURN)))
    _check("outer ring", ring_outer.Volume(), (A_out - A_out_in) * (Z_HI - Z_LO))
    lip = _valid("lip", slab(P.T_SKIN - 0.2, P.T_SKIN + P.D_RET_OUTER, n=P.N_LOFT).intersect(ring_outer))
    _check("lip", lip.Volume(), (A_out - A_out_in) * (P.D_RET_OUTER + 0.2), tol=0.2)
    ring_open = _valid("opening ring", _ring_prism(PF.opening_wire(offset=+P.T_WALL_OPEN), PF.opening_wire()))
    _check("opening ring", ring_open.Volume(), (A_open_out - A_open) * (Z_HI - Z_LO))
    # opening return profile = shallow return everywhere  U  deep wall along the TOP
    # edge of the opening, from the opening start to the step at WALL_TOP_END_S.
    # (Built as one profile, then ONE intersection with the ring: intersecting the
    # deep slab with the ring first gives an invalid OCC solid.)
    oi = PF.outline_polyline("opening", 1.0)
    y_mid = 0.5 * (oi[:, 1].max() + oi[:, 1].min())
    s0 = oi[:, 0].min() - 5.0
    box = cq.Solid.makeBox(P.WALL_TOP_END_S - s0, 40.0, Z_HI - Z_LO, cq.Vector(s0, y_mid, Z_LO))
    prof = slab(P.T_SKIN - 0.2, P.T_SKIN + P.D_RET_OPEN, n=P.N_LOFT).fuse(
        slab(P.T_SKIN - 0.2, P.T_SKIN + P.D_WALL_OPEN_TOP, n=P.N_LOFT).intersect(box))
    ret_open = _valid("opening return", prof.intersect(ring_open))

    body = _valid("body", skin.fuse(lip).fuse(ret_open).clean())
    _check("body", body.Volume(), skin.Volume() + lip.Volume() + ret_open.Volume()
           - 0.2 * ((A_out - A_out_in) + (A_open_out - A_open)), tol=0.08)
    rep["boolean_volume_checks"] = "passed (skin, opening cut, rings, lip, body)"
    # Visible-edge radii: OCC fillets on long spline edges can hang -> run them in a
    # child process with a time limit; on timeout/failure keep sharp edges (reported).
    import subprocess, tempfile, os, sys as _sys
    tmp = tempfile.mkdtemp()
    src, dst = os.path.join(tmp, "in.brep"), os.path.join(tmp, "out.brep")
    body.exportBrep(src)
    worker = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "fillet_worker.py")
    try:
        cp = subprocess.run([_sys.executable, worker, src, dst, str(P.R_OUTER_VISIBLE), str(P.R_INNER_VISIBLE)],
                            capture_output=True, text=True, timeout=getattr(P, "FILLET_TIMEOUT_S", 240))
        if cp.returncode == 0 and os.path.exists(dst):
            fb = cq.Shape.importBrep(dst)
            if fb.isValid():
                body = fb
            rep["visible_fillets"] = "applied: " + "; ".join(cp.stdout.strip().splitlines())
        else:
            rep["visible_fillets"] = "NOT applied (worker error): " + cp.stderr.strip()[-200:]
    except subprocess.TimeoutExpired:
        rep["visible_fillets"] = (f"NOT applied: OCC fillet did not finish in {getattr(P, 'FILLET_TIMEOUT_S', 240)} s "
                                  "on the spline edges -> sharp visible edges in V2 STEP (R_OUTER_VISIBLE/R_INNER_VISIBLE "
                                  "kept as parameters)")
    rep["body_valid"] = body.isValid()
    rep["body_volume_mm3"] = body.Volume()
    return body, rep
